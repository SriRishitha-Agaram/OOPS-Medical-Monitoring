# Medical Monitoring System
----------------------------

## Domain
---------
Healthcare / Life Sciences

## Problem Statement
---------------------
Hospitals need to track patient vitals (heart rate, blood pressure, temperature) continuously.  
Manual tracking is error-prone and delays critical responses.  

This system allows:
- Managing **patients** (basic info + history).
- Recording **vital signs** for patients.
- Monitoring vitals against **thresholds**.
- Triggering **alerts** when abnormal.
- Generating **reports** for patients and hospital-wide summaries.
- Storing patient data for later access.

---
## Project Structure
---------------------
medical_monitoring_system/
│
├── patient_management.py # Manage patients (add, update, list, history)
├── vital_signs.py        # Define vital signs object/structure
├── monitoring_service.py # Logic to check vitals against thresholds
├── alert_system.py       # Handle alerts when thresholds are exceeded
├── report_generation.py  # Generate reports and patient summaries
├── database_handler.py   # Simulate storage (in-memory or file DB)
├── main.py               # Menu-driven CLI entry point
├── README.md             # Project overview and student guide
└── requirements.txt      # Dependencies (if any)



## Topics Covered
------------------
- Object-Oriented Programming (Classes & Objects)
- Lists & Dictionaries for managing records
- Exception Handling
- File/Database Simulation
- Reports and Summaries
- Modular Programming
- CLI-based menu navigation

---

## Step-by-Step Workflow
-------------------------
1. Create a **Patient class** to store details and history.
2. Create a **VitalSigns class** for heart rate, BP, temperature.
3. Build a **Monitoring Service** to check against thresholds.
4. Implement an **Alert System** to capture abnormal cases.
5. Add a **Database Handler** to simulate storage.
6. Implement **Report Generation** for patients and system-level insights.
7. Write a **menu-driven CLI (main.py)** to connect everything.


## Students Work:
-----------------
- **Student A**: Patient Management (`patient_management.py`), Vital Signs (`vital_signs.py`)  
- **Student B**: Monitoring Service (`monitoring_service.py`), Alert System (`alert_system.py`)  
- **Student C**: Report Generation (`report_generation.py`), Database Handler (`database_handler.py`), Integrator (`main.py`)  

---

## How to run
cd medical_monitoring_system/
python main.py
